var express = require('express');
var router = express.Router();
const Email = require('email-templates');

const email = new Email({
  message: {
    from: 'no-reply@dinesh.com'
  },
  transport: {
    host: 'mail.smtp2go.com',
    port: 2525,
    secure: false,
    auth: {
        user: 'singletalent.com@gmail.com', 
        pass: 'njNX53wWRvbe'
    }
  }
});

router.get('/', function(req, res, next) {
  email
  .send({
    template: 'email-confirmation',
    message: {
      to: 'dineshrawataias@gmail.com'
    },
    locals: {
      name: 'Dinesh'
    }
  })
  .then(console.log)
  .catch(console.error);
  res.json({ title: 'Express' });
});

module.exports = router;
